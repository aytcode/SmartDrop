# 📁 SmartDrop - Akıllı & Güvenli Dosya Düzenleyici

Windows için **PySide6** ile geliştirilmiş, dağınık klasörleri (ör. `Downloads`, `Masaüstü`) otomatik analiz edip kategorilere ayıran, **kesinlikle kontrolsüz taşımayan**, her işlem öncesinde zengin bir önizleme sunan ve yapılan tüm işlemleri eksiksiz geri alabilen (undo) modern masaüstü uygulaması.

---

## 🌟 Öne Çıkan Özellikler

1. **Önizleme Zorunluluğu (Preview-First):**
   - Hiçbir dosya kullanıcı açıkça onaylamadan taşınmaz.
   - Dosya adı, kategori, hedef klasör, yeni isim ve dosya boyutu tablo halinde listelenir.
   - Kullanıcı dilediği dosyanın seçimini kaldırabilir, hedefini veya adını değiştirebilir.

2. **Sıfır Veri Kaybı & Güvenlik Kalkanı:**
   - **Asla Dosya Silmez:** Uygulamada silme işlemi (delete/unlink) yoktur.
   - **Asla Üzerine Yazmaz (Zero-Overwrite):** Hedefte veya geri alma sırasında aynı isimde dosya varsa otomatik olarak `dosya (1).ext`, `dosya (2).ext` şeklinde benzersiz isim üretilir.
   - **Sistem Klasörleri Koruması:** `C:\Windows`, `C:\Program Files`, `System32`, `ProgramData` ve kök sürücüler (`C:\`) kesinlikle düzenlenemez.

3. **Geri Alma (Undo) Sistemi:**
   - Yapılan her taşıma işlemi `.smartdrop_history.json` dosyasında loglanır.
   - "Son İşlemi Geri Al" butonuyla tüm dosyalar orijinal konumlarına geri taşınır.
   - İşlem sonrasında boşalan kategori klasörleri otomatik olarak temizlenir.

4. **11 Temel Kategori & Akıllı Sınıflandırma:**
   - **Documents:** `.pdf`, `.doc`, `.docx`, `.txt`, `.rtf`, `.odt`, `.md`
   - **Images:** `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`, `.svg`, `.bmp`
   - **Videos:** `.mp4`, `.mkv`, `.avi`, `.mov`, `.wmv`
   - **Audio:** `.mp3`, `.wav`, `.flac`, `.aac`, `.ogg`
   - **Archives:** `.zip`, `.rar`, `.7z`, `.tar`, `.gz`
   - **Code:** `.py`, `.js`, `.ts`, `.html`, `.css`, `.json`, `.cpp`, `.java`, `.sql`
   - **Spreadsheets:** `.xls`, `.xlsx`, `.csv`, `.tsv`
   - **Presentations:** `.ppt`, `.pptx`, `.key`
   - **Installers:** `.exe`, `.msi`, `.dmg`, `.pkg`
   - **Fonts:** `.ttf`, `.otf`, `.woff`, `.woff2`
   - **Others:** Bilinmeyen veya uzantısız dosyalar.

5. **Akıllı Adlandırma & AI Desteği (İsteğe Bağlı):**
   - Kamera/ekran görüntüsü karmaşasını temizler (`IMG_20260920_1832.png` -> `photo_20260920_1832.png`, `doc(4).pdf` -> `doc_4.pdf`).
   - Küçük metin ve veri dosyaları için yerel anlamsal içerik analizi.
   - İsteğe bağlı Gemini AI API entegrasyonu.

6. **Donmayan Arayüz (Multithreading):**
   - Tarama ve dosya taşıma işlemleri `QThread` arka plan iş parçacıklarında çalışır, UI asla kilitlenmez.

7. **Geliştirici & Test Modu:**
   - Tek tıkla `test_data/sample_downloads/` içinde farklı uzantı ve uç durumlara (Türkçe karakterler, boşluklu isimler, uzun adlar) sahip örnek dosyalar oluşturur.
   - Arayüzden doğrudan tüm `pytest` testlerini çalıştırabilme.

---

## 📂 Proje Yapısı

```
smartdrop/
├── app.py                     # Ana uygulama başlatıcı
├── ui/                        # PySide6 Grafiksel Kullanıcı Arayüzü
│   ├── main_window.py         # Ana pencere ve QThread iş parçacıkları
│   ├── preview_table.py       # Etkileşimli önizleme tablosu
│   ├── settings_dialog.py     # Ayarlar ve kategori adlandırma penceresi
│   └── styles.py              # Windows 11 Fluent Açık/Koyu tema QSS stilleri
├── core/                      # Temel İş Mantığı Motoru
│   ├── scanner.py             # Klasör tarayıcı ve önizleme oluşturucu
│   ├── classifier.py          # Uzantı ve kural tabanlı sınıflandırıcı
│   ├── organizer.py           # Güvenli taşıma ve çarpışma önleyici
│   ├── safety.py              # Sistem koruma ve yol doğrulama
│   ├── undo_manager.py        # İşlem geçmişi ve geri alma yöneticisi
│   └── renamer.py             # Akıllı dosya yeniden adlandırma
├── services/                  # Servis Katmanı
│   ├── ai_service.py          # Yerel anlamsal analiz & opsiyonel Gemini AI
│   └── logger_service.py      # Gerçek zamanlı işlem log servisi
├── models/                    # Veri Modelleri
│   ├── config.py              # Kullanıcı ayarları (SmartDropConfig)
│   ├── file_item.py           # İncelenen dosya modeli (FileItem)
│   └── operation.py           # Taşıma işlemi ve geçmiş modeli
├── utils/                     # Yardımcı Araçlar
│   ├── file_utils.py          # Boyut formatlama, çarpışma çözücü, gizli dosya
│   ├── system_paths.py        # Windows sistem klasör korumaları
│   └── test_helper.py         # Örnek test verisi oluşturucu
├── tests/                     # Kapsamlı pytest Test Paketi
│   ├── conftest.py            # Test raporu kancası (SMARTDROP TEST REPORT)
│   ├── test_file_classification.py # 15 dosya türü otomatik kategori doğrulaması
│   ├── test_duplicate_files.py     # Çift dosya, çakışma ve sıfır üzerine yazma
│   ├── test_undo.py           # Eksiksiz geri alma ve klasör temizleme
│   ├── test_file_names.py     # Türkçe karakterler ve önizleme bütünlüğü
│   ├── test_unknown_extensions.py  # Bilinmeyen uzantılar (.xyz) ve boş klasör
│   ├── test_error_handling.py # İzolasyon ve tek hata toleransı
│   └── test_repeated_runs.py  # İdempotentlik ve tekrar çalıştırma kontrolü
├── tools/
│   └── create_test_data.py    # Güvenli örnek indirme test verisi üretici
├── test_data/                 # Test klasörleri ve örnekleri
├── requirements.txt           # Bağımlılıklar
├── setup.bat                  # Windows tek tıkla kurulum
├── run.bat                    # Windows tek tıkla çalıştırma
└── README.md                  # Dokümantasyon
```

---

## 🚀 Kurulum (Windows)

### 1. Gereksinimler
- Python 3.12+ (veya Python 3.10+)
- `pip` paket yöneticisi

### 2. Hızlı Kurulum (Windows)
Klasör içindeki `setup.bat` dosyasına çift tıklayarak veya komut satırından:

```powershell
# Gerekli kütüphaneleri yükleyin:
pip install -r requirements.txt
```

### 3. Uygulamayı Başlatma
`run.bat` dosyasına çift tıklayabilir veya komut satırında:

```powershell
python app.py
```

veya modül olarak:

```powershell
python -m smartdrop.app
```

---

## 🧪 Test Sistemi & Çalıştırma

### 1. Örnek Test Verisi Oluşturucu
Gerçek kullanıcı dosyalarına kesinlikle dokunmadan, geçici test ve deneme için örnek dosyaları oluşturmak için:

```powershell
python tools/create_test_data.py
```

Bu script `test_data/sample_downloads/` içinde `photo.jpg`, `image.png`, `document.pdf`, `notes.txt`, `video.mp4`, `song.mp3`, `archive.zip`, `script.py`, `app.js`, `data.csv`, `table.xlsx`, `slides.pptx`, `program.exe`, `font.ttf`, `unknown.xyz`, Türkçe karakterli dosyalar (`ödev.pdf`, `çalışma.docx`, `şarkı.mp3`, `görsel.png`) oluşturur.

### 2. Otomatik Pytest Testlerini Çalıştırma
Tüm birim testleri ve uç durum senaryolarını çalıştırmak için:

```powershell
python -m pytest -v
```

veya sadece `tests/` paketini çalıştırmak için:

```powershell
python -m pytest tests -v
```

### Test Rapor Çıktısı Formatı:
```
========================================
SMARTDROP TEST REPORT
========================================
Passed:  39
Failed:  0
Skipped: 0
========================================
```

Bir test başarısız olduğunda rapor test adını, beklenen sonucu ve hata sebebini açıkça gösterir.

### Test Edilen Uç Durumlar:
- ✅ **15 Temel Dosya Türü Sınıflandırması:** `photo.jpg`, `image.png`, `document.pdf`, `notes.txt`, `video.mp4`, `song.mp3`, `archive.zip`, `script.py`, `app.js`, `data.csv`, `table.xlsx`, `slides.pptx`, `program.exe`, `font.ttf`, `unknown.xyz`
- ✅ **Duplicate & Zero Overwrite:** Aynı isimde dosya geldiğinde `photo (1).jpg` üretilmesi ve hedefteki dosyanın kesinlikle değiştirilmemesi
- ✅ **Eksiksiz Undo:** Organize edilen dosyaların orijinal konumlarına dönmesi ve boş kalan kategori klasörlerinin silinmesi
- ✅ **Türkçe Karakter Bütünlüğü:** `ödev.pdf`, `çalışma.docx`, `şarkı.mp3`, `görsel.png` adlarının bozulmadan taşınması
- ✅ **Önizleme Güvenliği (Preview Integrity):** Önizleme ve tarama aşamasında asla dosya taşınmaması/değiştirilmemesi
- ✅ **Bilinmeyen Uzantılar:** `unknown.xyz` ve uzantısız dosyaların `Others` kategorisine yönlendirilmesi
- ✅ **Boş Klasör:** Boş klasörün hatasız taranması
- ✅ **İdempotentlik:** Arka arkaya iki kez çalıştırmada dosyaların gereksiz yere tekrar taşınmaması
- ✅ **Hata İzolasyonu:** Taşınamayan tek bir kilitli/hatalı dosyanın diğer dosyaların taşınmasını durdurmaması
- ✅ Tekrar tekrar çalıştırma (idempotency - dosyalar tekrar tekrar iç içe taşınmaz)
- ✅ Eksiksiz Undo (geri alma) ve boşalan klasörlerin temizlenmesi
- ✅ Windows sistem klasörlerine (`C:\Windows`, `Program Files`, root) erişimin engellenmesi

---

## 🛡️ Güvenlik Politikası

- Hiçbir şart altında dosya **SİLİNMEZ**.
- Hedefte dosya varsa **ASLA ÜZERİNE YAZILMAZ** (`resolve_collision` mekanizması çalışır).
- Yanlışlıkla Windows veya Program Files seçilirse uygulama kullanıcıyı uyarır ve işlemi durdurur.
- Yapılan her işlem anında JSON loguna yazılır; elektrik kesintisi veya kapanma durumunda dahi geri alma geçerliliğini korur.
